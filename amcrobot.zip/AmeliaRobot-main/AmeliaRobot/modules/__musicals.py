__mod_name__ = "◎Music"

__help__ = """
/saavn <i>query</i>: download song from Saavn servers.
/deezer <i>query</i>: download from deezer.
/video <i>query</i>: download video from youtube
/song <i>query</i>: download from youtube
/lyrics <i>song name</i> : This plugin searches for song lyrics with song name.
/glyrics <i> song name </i> : This plugin searches for song lyrics with song name and artist.
"""
