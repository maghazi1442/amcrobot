__help__ = f"""
 ❍ /nightmode on/off
 
Set NightMode - /setnightmode timezone : 12:00:00 PM : 07:00:00 AM
**Note:** Now you can choose your counrty time zone and opening and closing time also.
"""

__mod_name__ = "NightMode"

